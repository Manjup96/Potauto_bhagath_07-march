<style>
    /*.breadcrumbs_area{*/
    /*    min-height:300px;*/
    /*    background-color:#f9cf1f;*/
    /*    background : url("images/ban555.jpg");*/
    /*    background-size:cover;*/
    /*}*/
    
 .slider_section{
     border-bottom: 3px solid #feca26;
 }

</style> 
 
 
 <!--<div class="breadcrumbs_area">-->
 <!--       <div class="container">   -->
 <!--           <div class="row">-->
 <!--               <div class="col-12">-->
 <!--                   <div class="breadcrumb_content">-->
 <!--                       <h2 style="text-align:center;">About Us</h2>-->
                        <!--<marquee onmouseout="this.start();" onmouseover="this.stop();" scrollamount="20" id="myMarquee" class="example"  scrolldelay="200"><img class="mar_img" src="images/abt-banner.png"/></marquee>-->
                        <!--<ul>-->
                        <!--    <li><a href="index.php">home</a></li>-->
                        <!--    <li>about us</li>-->
                        <!--</ul>-->
 <!--                   </div>-->
 <!--               </div>-->
 <!--           </div>-->
 <!--       </div>         -->
 <!--   </div>-->
 
 
 
   <section class="slider_section mb-40" >
        <div class="slider_area slider_carousel owl-carousel">
            <div class="single_slider d-flex align-items-center" data-bgimg="images/ban555.jpg" style="background-size:cover;">
               <div class="container">
                   <div class="row">
                       <div class="col-12">
                           <!--<div class="slider_content">-->
                           <!--     <h1>Big sale off <span>Accessories Fidanza</span></h1>-->
                           <!--     <p>Exclusive Offer -30% Off This Week</p>  -->
                           <!--     <a class="button" href="shop.html">shopping now <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>-->
                           <!-- </div>-->
                       </div>
                   </div>
               </div> 
            </div>
            </div>
            </section>