<!--  <div class="newsletter_area newsletter_padding">
        <div class="container">
            <div class="newsletter_inner">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="newsletter_container">
                            <h3>Follow Us</h3>
                            <p>We make consolidating, marketing and tracking your social media website easy.</p>
                            <div class="footer_social">
                               <ul>
                                   <li><a class="facebook" href="#"><i class="icon-facebook"></i></a></li>
                                   <li><a class="twitter" href="#"><i class="icon-twitter2"></i></a></li>
                                   <li><a class="rss" href="#"><i class="icon-rss"></i></a></li>
                                   <li><a class="youtube" href="#"><i class="icon-youtube"></i></a></li>
                                   <li><a class="google" href="#"><i class="icon-google"></i></a></li>
                                   <li><a class="instagram2" href="#"><i class="icon-instagram2"></i></a></li>
                               </ul>
                           </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="newsletter_container">
                            <h3>Newsletter Now</h3>
                            <p>Join 60.000+ subscribers and get a new discount coupon on every Wednesday.</p>
                            <div class="subscribe_form">
                                <form id="mc-form" class="mc-form footer-newsletter" >
                                    <input id="mc-email" type="email" autocomplete="off" placeholder="Enter you email address here..." />
                                    <button id="mc-submit">Subscribe</button>
                                </form>
                                <!-- mailchimp-alerts Start -->
                              <!--  <div class="mailchimp-alerts text-centre">
                                    <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                 <!--   <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                   <!-- <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                               <!-- </div><!-- mailchimp-alerts end -->
                           <!-- </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-7">
                        <div class="newsletter_container col_3">
                            <h3>GET THE APP</h3>
                            <p>Mazlay App is now available on Google Play & App Store. Get it now.</p>
                            <div class="app_img">
                               <ul>
                                   <li><a href="#"><img src="assets/img/icon/icon-app.jpg" alt=""></a></li>
                                   <li><a href="#"><img src="assets/img/icon/icon1-app.jpg" alt=""></a></li>
                               </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
<html>
    <body>
        <style>

                /* footer_widgets
                {
                background-image: url('images/footer_logo.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                } */

            </style>

 <footer class="footer_widgets">
        <!--shipping area start-->
       <!--  <div class="shipping_area">
            <div class="container">
                <div class="shipping_inner">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping1.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h4>Free Delivery</h4>
                            <p>For all oders over $120</p>
                        </div>
                    </div>
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping2.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h4>Free Delivery</h4>
                            <p>For all oders over $120</p>
                        </div>
                    </div>
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping3.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h4>Free Delivery</h4>
                            <p>For all oders over $120</p>
                        </div>
                    </div>
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping4.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h4>Free Delivery</h4>
                            <p>For all oders over $120</p>
                        </div>
                    </div>
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping5.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h4>Free Delivery</h4>
                            <p>For all oders over $120</p>
                        </div>
                    </div>
                </div>
            </div>             
        </div> -->
        <!--shipping area end-->



        <!-- Footer Start -->
<div class="footer-wrap"  style="width: 1420px;">
    <div class="container-fluid">
        <div class="row">
            <!--
                    <div class="col-lg-1 col-md-4">
                   </div>
                <div class="col-lg-3" style="color:white;">
                        <div class="footer_logo">
                            <img alt=""  src="images/footer-pot.png" style="margin: 20px 0;">
                        </div>
                            <h3 style="color:#f9cf1f;";margin: 10px 0;">POTAUTO  Auto India Pvt. Ltd.</h3>
                        
                            <p style="text-align:justify;margin: 10px 0;"> <br/>
                            India's Biggest Online Marketplace For Auto Mobile Spare Parts 
                            </p>
                </div>
                <div class="col-lg-2 col-md-4"  style="color:white;">
                            <h3> <br>Quick links</h3>
                            <ul class="footer-links">
                                                    <li style="margin: 10px 0;"><a href="about.php">About Us</a></li> 
                                                            <li style="margin: 10px 0;"><a href="#">Enquiry for bulk orders</a></li> 
                                                            
                                                            <li style="margin: 10px 0;"><a href="#">Terms and Conditions</a></li> 
                                                            <li style="margin: 10px 0;"><a href="#">Privacy Policy</a></li> 
                            </ul>
                </div> 
                
                <div class="col-lg-2 col-md-4">
                            <div class="footer_info" style="color:white;">
                                    <h3  ><br> Get in Touch</h3>
                                    <ul class="footer-adress">
                                        <li class="footer_address" style="margin: 10px 0;"> <i class="fas fa-map-signs"></i> <span>5/1, MADANAYAKANAHALLI,<br/> LAKSHMIPURA ROAD ,TUMKUR ROAD,<br/> BENGALURU-562123, <br/>KARNATAKA, INDIA.</span> </li>
                                        <li class="footer_email" style="margin: 10px 0;"> <span>&#9993;</span>
                                                <span><a href="mailto:info@jiomex.com"> info@jiomex.com </a></span> </li>
                                        <li class="footer_phone" style="margin: 10px 0;"> 
                                        <span>  &#128222;</span>
                                            <span><a href="tel:8884463025"> +91-8884463025</a></span> </li>
                                    </ul> 
                            
                            </div>
                    </div>
                    <div class="col-lg-1 col-md-4">
                        <div class="footer_info" style="color:white;">
                            <h3  ><br> Follow Us</h3>

                                    <div class="offcanvas_footer">
                                                <ul>
                                                <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                    <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                    <li class="pinterest"><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                                    <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                                    <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                                </ul> 
                                    </div>
                    
                        </div>
                     </div> -->
                     <div class="col-lg-1 col-md-4">
                   </div>
                <div class="col-lg-4 col-md-4" style="color:white;">
                        <div class="footer_logo">
                            <!-- <img alt=""  src="images/footer-pot.png" style="margin: 20px 0;"> -->
                        </div>
                            <h3 style="color:#f9cf1f;";margin: 10px 0;">POTAUTO  Auto India Pvt. Ltd.</h3>
                        
                            <p style="text-align:justify;margin: 10px 0;"> <br/>
                            India's No.1 Distibutor of Auto Mobile Spare Parts 
                            </p>
                </div>
                
                <div class="col-lg-2 col-md-4"  style="color:white;">
                            <h3> <br>Quick links</h3>
                            <ul class="footer-links">
                                                    <li style="margin: 10px 0;"><a href="about.php">About Us</a></li> 
                                                            <li style="margin: 10px 0;"><a href="#">Enquiry for bulk orders</a></li> 
                                                            
                                                            <li style="margin: 10px 0;"><a href="#">Terms and Conditions</a></li> 
                                                            <li style="margin: 10px 0;"><a href="#">Privacy Policy</a></li> 
                            </ul>
                </div> 
                
                <div class="col-lg-2 col-md-4">
                            <div class="footer_info" style="color:white;">
                                    <h3  ><br> Get in Touch</h3>
                                    <ul class="footer-adress">
                                        <li class="footer_address" style="margin: 10px 0;"> <i class="fas fa-map-signs"></i> <span>5/1, MADANAYAKANAHALLI,<br/> LAKSHMIPURA ROAD ,TUMKUR ROAD,<br/> BENGALURU-562123, <br/>KARNATAKA, INDIA.</span> </li>
                                        <li class="footer_email" style="margin: 10px 0;"> <span>&#9993;</span>
                                                <span><a href="mailto:info@jiomex.com"> info@jiomex.com </a></span> </li>
                                        <li class="footer_phone" style="margin: 10px 0;"> 
                                        <span>  &#128222;</span>
                                            <span><a href="tel:8884463013"> +91-8884463013</a></span> </li>
                                    </ul> 
                                    
                            
                            </div>
                    </div>
                    <div class="col-lg-2 col-md-4">
                            <div class="footer_info" style="color:white;">
                                <h3  ><br> Follow Us</h3>

                                    <div class="offcanvas_footer">
                                                <ul>
                                                <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                    <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                    <li class="pinterest"><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                                    <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                                    <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                                </ul> 
                                    </div>
                    
                            </div>
                     </div> 
                     <div class="col-lg-1 col-md-4">
                   </div>
        
        </div>

    </div>
</div>

</footer> 
<!-- Footer End --> 
</body>
</html>
    
   
<!--Copyright Start--> 
<div class="footer-bottom text-center"> <br>
  <div class="container" > 
  <p  style="color:#27569e">
                                &copy; 
                                
                                <a href="#" class="text-uppercase" >
                                     Copyright POTAUTO  Auto India Pvt. Ltd. All Rights Reserved  
                                </a>
                                <!-- . Developed By <a target="_blank" href="https://www.iiiqbets.com">iiiQbets

                                </a> --> 
                                <?php echo date("Y"); ?> 
                            </p>  <br>
  </div>
</div>
<!--Copyright End--> 