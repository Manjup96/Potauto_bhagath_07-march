 <footer class="footer">
            <p><?php echo date('Y');?> © Potauto Auto Accessories</p>
        </footer>